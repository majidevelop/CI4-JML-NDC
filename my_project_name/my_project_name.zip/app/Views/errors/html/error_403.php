<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Access Denied</title>
</head>
<body>
    <h1>403 - Access Denied</h1>
    <p>You must be logged in to access this page.</p>
</body>
</html>